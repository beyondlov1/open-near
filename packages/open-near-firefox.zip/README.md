# open-near

## firefox
```
  "background": {
    "scripts": ["/background/background.js"]
  }

```

## chrome
```
  "background": {
    "service_worker": "/background/background.js",
  }

```
